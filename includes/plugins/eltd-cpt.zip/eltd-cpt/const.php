<?php

define('ELATED_CORE_VERSION', '1.1.1');
define('ELATED_CORE_ABS_PATH', dirname(__FILE__));
define('ELATED_CORE_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELATED_CORE_CPT_PATH', ELATED_CORE_ABS_PATH.'/post-types');