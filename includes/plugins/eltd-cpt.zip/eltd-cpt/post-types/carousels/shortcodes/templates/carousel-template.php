<div class="eltd-carousel-item-holder" <?php echo chandelier_elated_inline_style($carousel_item_style); ?>>
	<?php if ($link !== '') { ?>
	<a href="<?php echo esc_url($link)?>" target="<?php echo esc_attr($target)?>">
	<?php } ?>
		<?php if ($image !== '') { ?>
			<span class="eltd-carousel-first-image-holder <?php echo esc_attr($hover_class); ?> <?php echo esc_attr($carousel_image_classes); ?>">
				<img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_html($title); ?>">
			</span>
		<?php } ?>
		<?php if ($hover_image !== '') { ?>
			<span class="eltd-carousel-second-image-holder <?php echo esc_attr($hover_class); ?> <?php echo esc_attr($carousel_image_classes); ?>" <?php echo chandelier_elated_inline_style($second_image_style); ?>>
				<img src="<?php echo esc_url($hover_image); ?>" alt="<?php echo esc_html($title); ?>">
			</span>
		<?php } ?>
	<?php if ($link !== '') { ?>
	</a>
	<?php } ?>
</div>