<?php if($query_results->max_num_pages>1){ ?>
	<div class="eltd-ptf-list-paging">
		<span class="eltd-ptf-list-load-more">
			<?php 
				echo chandelier_elated_get_button_html(array(
					'link' => 'javascript: void(0)',
					'text' => 'Show more'
				));
			?>
		</span>
	</div>
<?php }