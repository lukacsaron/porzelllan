
<article class="eltd-portfolio-item mix <?php echo esc_attr($categories)?>">
	
	<div class = "eltd-item-image-holder">
		<a href="<?php echo esc_url($portfolio_url) ?>">
			<?php
				echo get_the_post_thumbnail(get_the_ID(),$thumb_size);
			
			?>			
			<span class="eltd-item-shader"></span>
		</a>
	</div>
	<div class="eltd-item-text-holder">
		<<?php echo esc_attr($title_tag)?> class="eltd-item-title">
			<a href="<?php echo esc_url($portfolio_url) ?>">
				<?php echo esc_attr(get_the_title()); ?>
			</a>	
		</<?php echo esc_attr($title_tag)?>>
		<p class="eltd-article-excerpt">
			<?php
				echo $article_excerpt;
			?>
		</p>
		<?php
		if($hide_category !== 'yes'){
			echo $category_html;
		}		
		?>
	</div>
</article>


