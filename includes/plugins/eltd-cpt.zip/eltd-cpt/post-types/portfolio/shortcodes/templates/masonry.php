<article class="eltd-portfolio-item <?php echo esc_attr($article_masonry_size)?> <?php echo esc_attr($categories)?>">
	<div class = "eltd-item-image-holder">
		<a href="<?php echo esc_url($portfolio_url) ?>" class="eltd-portfolio-link"></a>
		<div class="eltd-ptf-image-holder">
			<?php
				echo get_the_post_thumbnail(get_the_ID(),$thumb_size);
			?>
		</div>			
		<div class="eltd-item-text-holder">
			<<?php echo esc_attr($title_tag)?> class="eltd-item-title">
				<a href="<?php echo esc_url($portfolio_url) ?>">
					<?php echo esc_attr(get_the_title()); ?>
				</a>	
			</<?php echo esc_attr($title_tag)?>>	
			<?php
			if($hide_category !== 'yes'){
				echo $category_html;
			}
			?>
		</div>
	</div>
</article>
