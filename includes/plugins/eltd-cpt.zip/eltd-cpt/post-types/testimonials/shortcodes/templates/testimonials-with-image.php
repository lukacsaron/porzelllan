<div id="eltd-testimonials<?php echo esc_attr($current_id) ?>" class="eltd-testimonial-content eltd-testimonials-with-image">
	<?php if (has_post_thumbnail($current_id)) { ?>
		<div class="eltd-testimonial-image-holder">
			<?php esc_url(the_post_thumbnail($current_id)) ?>
		</div>
	<?php } ?>
	<div class="eltd-testimonial-content-inner">
		<div class="eltd-testimonial-text-holder">
			<div class="eltd-testimonial-icon-holder">
				<?php print $icon; ?>
			</div>
			<div class="eltd-testimonial-text-inner">
				<?php if($show_title == "yes"){ ?>
					<p class="eltd-testimonial-title">
						<?php echo esc_html($title) ?>
					</p>
				<?php }?>
				<p class="eltd-testimonial-text"><?php echo trim($text) ?></p>
				<?php if ($show_author == "yes") { ?>
					<div class = "eltd-testimonial-author">
						<p class="eltd-testimonial-author-text"><?php echo esc_html($author)?>
							<?php if($website !== ''){ ?>
								- <a href="<?php echo esc_url($website)?>" target="_blank" class="eltd-testimonials-website"><?php echo esc_html($website)?></a>
							<?php } ?>
							<?php if($show_position == "yes" && $job !== ''){ ?>
								- <span class="eltd-testimonials-job"><?php echo esc_html($job)?></span>
							<?php }?>
						</p>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>